`timescale 1ns/1ns
`define CLK_PERIOD 20

module tb_multi_pipe;

    reg [7:0] mul_a;
    reg [7:0] mul_b;
    reg mul_en_in;
    reg clk;
    reg rst_n;

    wire mul_en_out;
    wire [15:0] mul_out;

    integer errors;
    integer i;
    integer wait_cycles;
    reg [15:0] expected_product;

    multi_pipe_8bit dut (
        .clk(clk),
        .rst_n(rst_n),
        .mul_a(mul_a),
        .mul_b(mul_b),
        .mul_en_in(mul_en_in),
        .mul_en_out(mul_en_out),
        .mul_out(mul_out)
    );

    initial clk = 1'b0;
    always #10 clk = ~clk;

    task sample_outputs;
        begin
            @(posedge clk);
            #1;
            if (mul_en_out !== 1'b0 && mul_en_out !== 1'b1) begin
                errors = errors + 1;
                $display("mul_en_out is X/Z");
            end
            if (mul_en_out === 1'b0 && mul_out !== 16'd0) begin
                errors = errors + 1;
                $display("mul_out must be 0 whenever mul_en_out is low, got %0d", mul_out);
            end
        end
    endtask

    task issue_and_expect;
        input [7:0] a_in;
        input [7:0] b_in;
        begin
            expected_product = a_in * b_in;

            @(negedge clk);
            mul_a = a_in;
            mul_b = b_in;
            mul_en_in = 1'b1;

            @(posedge clk);
            #1;
            mul_en_in = 1'b0;

            wait_cycles = 0;
            while (mul_en_out !== 1'b1 && wait_cycles < 20) begin
                sample_outputs;
                wait_cycles = wait_cycles + 1;
            end

            if (mul_en_out !== 1'b1) begin
                errors = errors + 1;
                $display("mul_en_out never asserted for %0d * %0d", a_in, b_in);
            end else if (mul_out !== expected_product) begin
                errors = errors + 1;
                $display("Wrong product for %0d * %0d: got %0d expected %0d", a_in, b_in, mul_out, expected_product);
            end

            // The valid result should not persist forever once the pipeline advances.
            sample_outputs;
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 1'b0;
        mul_a = 8'd0;
        mul_b = 8'd0;
        mul_en_in = 1'b0;

        repeat (3) sample_outputs;
        rst_n = 1'b1;
        repeat (2) sample_outputs;

        issue_and_expect(8'd35, 8'd20);
        issue_and_expect(8'd0, 8'd200);
        issue_and_expect(8'd255, 8'd1);
        issue_and_expect(8'd13, 8'd17);

        for (i = 0; i < 8; i = i + 1) begin
            issue_and_expect($random, $random);
        end

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
