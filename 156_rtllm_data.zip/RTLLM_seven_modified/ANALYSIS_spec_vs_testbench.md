# RTLLM2.0 Seven Tasks: Contradictions Between Spec and Testbench

This document analyzes the following seven tasks:

- `alu`
- `multi_pipe_8bit`
- `parallel2serial`
- `traffic_light`
- `width_8to16`
- `asyn_fifo`
- `fixed_point_substractor`

The goal is not to decide whether the reference RTL is "truly correct". The
goal is to judge:

1. whether the current `design_description.txt` is self-contradictory or
   clearly deviates from the intended task meaning
2. whether the current `testbench.v` tests behavior that the spec never
   explicitly requires, or conversely fails to test key semantics that the
   spec does require
3. which issues should be prioritized if we only revise the testbench

Additional notes:

- The first half of this document explains the contradictions between the
  original benchmark spec and testbench.
- Each task ends with a "Current targeted revision" section describing the
  concrete testbench changes that are already reflected in
  `RTLLM_seven_modified/`.
- These targeted revisions were cross-checked against the actual released
  `testbench.v` files.

## Summary Table

| Task | Main source of the problem | Short description |
|---|---|---|
| `alu` | both `spec` and `tb` are problematic | the spec has internal semantic conflicts, while the testbench almost only checks `r` and barely checks any flags |
| `multi_pipe_8bit` | mainly a `tb` problem | the testbench assumes a fixed pipeline latency that never appears in the spec |
| `parallel2serial` | ambiguous `spec`, overcommitted `tb` interpretation | the meaning of `valid_out` is unclear, while the testbench assumes a fixed four-cycle resend rhythm |
| `traffic_light` | mainly a `spec` problem, and the `tb` follows a flawed implementation sketch | the top-level text says 60/5/10, but the later implementation sketch transitions at `cnt==3` |
| `width_8to16` | ambiguous `spec`, race-prone `tb` | "output on the next cycle after the second input" does not align cleanly with the sampling behavior of the reference RTL / testbench |
| `asyn_fifo` | mainly a `spec` problem, plus `tb` compatibility issues | the task simultaneously says `DEPTH=16` and "depth 8 / 4-bit Gray / lower 3 bits address" |
| `fixed_point_substractor` | both `spec` and `tb` are problematic | as a subtractor, its branch-level arithmetic logic is itself mathematically wrong |

## 1. `alu`

### Findings

- The top-level spec says `flag` is the "result" of `slt/sltu`.
- But later text says `flag` should simply be `1` for `SLT` or `SLTU`, and `z`
  otherwise.
- The spec also says that `LUI` concatenates the upper 16 bits of `a` with
  sixteen zeroes.
- However, the current `reference.dat` LUI result is `001c0000`. For the fixed
  testbench input `a = 32'h0000001c`, that corresponds to
  `{a[15:0], 16'h0000}`, not the literal "upper 16 bits" behavior required by
  the spec.
- The testbench only compares `reference[cnt] != r` and does not check
  `zero/carry/negative/overflow/flag` at all.
- The testbench reads `reference[0:31]`, but the file only has 17 lines, so the
  simulation emits a `Not enough words in the file for the requested range
  [0:31]` warning.

### Diagnosis

- This is a classic task where both the `spec` and the `tb` are contaminated.
- The `spec` has at least two internal conflicts:
  - is `flag` the comparison result, or is it always `1` whenever the opcode is
    `SLT/SLTU`?
  - should `LUI` use `a[31:16]` or `a[15:0]`?
- The `tb` is also severely under-specified: it effectively reduces a
  multi-flag ALU into a "17-opcode single-instance lookup table check".

### If We Only Fix the Testbench

- We must add coverage for `zero/carry/negative/overflow/flag`.
- We must add multiple input cases instead of using only
  `a=0x1c, b=0x21`.
- The expected value for `LUI` should be checked directly according to the
  literal "upper 16 bits" wording in the spec.
- If we tighten the testbench to the literal spec wording, then `flag` should
  more naturally be tested as "`1` for `SLT/SLTU`, `z` otherwise" rather than
  by injecting common ALU priors.

### Current Targeted Revision

- Removed the single-point `reference.dat` lookup and replaced it with multiple
  representative operation checks.
- Expanded the test from only `r` to `r / zero / negative / overflow`, and also
  checked `carry` in the relevant cases.
- Checked the `SLT/SLTU` `flag` behavior and the `LUI` result directly against
  the literal spec wording.

## 2. `multi_pipe_8bit`

### Findings

- The spec says this is a pipelined multiplier, but it never gives a fixed
  latency. It only says `mul_en_out` comes from the highest bit of
  `mul_en_out_reg`.
- After driving an input, the original testbench first performs an "if the
  correct result appears too early, count it as an error" check:
  - if `mul_en_out==1` and `mul_out==expected_product` at that earlier point,
    it actually increments `error`
- The testbench then waits in `while (mul_en_out == 0)` until the output is
  declared valid.

### Diagnosis

- The main problem here is in the `tb`.
- The spec says only that the design is pipelined and that validity is signaled
  through `mul_en_out`; it does not say that a correct result is forbidden from
  appearing earlier.
- The current testbench effectively hard-codes the pipeline depth of one
  particular reference implementation into the task definition.

### If We Only Fix the Testbench

- We should not punish designs that have a shorter latency than the reference
  implementation but are semantically correct.
- The correct strategy is:
  - record `mul_a/mul_b` when `mul_en_in` is high
  - whenever `mul_en_out` goes high in the future, check that `mul_out` matches
    the sampled product
- If we truly want to require a fixed latency, then that latency must be written
  back into the spec explicitly. The testbench should not decide it privately.

### Current Targeted Revision

- Removed the "correct result too early means failure" logic.
- Changed the test to wait for `mul_en_out` and then check
  `mul_out == mul_a * mul_b`.
- Added a check that `mul_out` should be `0` while `mul_en_out == 0`, and added
  multiple input cases.

## 3. `parallel2serial`

### Findings

- The opening spec text says that `valid_out=1` means "valid serial output
  available".
- In the same sentence, it also says that when `valid_out=1`, the module outputs
  the MSB, and the remaining three bits are output sequentially in the next
  three cycles.
- This creates semantic ambiguity:
  - is only the first cycle considered "valid"?
  - or do the next three cycles still belong to the same valid serial output,
    just with `valid_out=0`?
- The original testbench adopts a very specific interpretation:
  - cycle 1 checks `d[3]` and `valid_out==1`
  - the next three cycles check `d[2], d[1], d[0]` with `valid_out==0`
  - cycle 5 again requires `valid_out==1`
- That is equivalent to assuming:
  - the module has no input handshake
  - the same `d` is reloaded and retransmitted every four cycles

### Diagnosis

- This task looks more like "an ambiguous `spec` plus a too-strong, too-specific
  `tb` interpretation".
- The current testbench is really testing a "fixed four-cycle looping
  serializer", not a more general "parallel-to-serial converter".

### If We Only Fix the Testbench

- We first need to decide the contract for `valid_out`:
  - is it a "frame start pulse"?
  - or is it a per-cycle "`dout` is currently valid" signal?
- We also need to decide whether:
  - `d` is automatically resampled every four cycles
  - or it is sampled only at specific frame boundaries
- Until those interface contracts are made explicit, the current testbench is
  too opinionated.

### Current Targeted Revision

- Kept the frame-level interpretation used by the current testbench:
  `valid_out=1` marks the start of a frame, and the remaining three bits follow
  over the next three cycles.
- Changed the check from hard-coded cycle points to "wait for frame start, then
  verify the bits sequentially".
- Added a second `d` input to confirm that the next frame reloads a new parallel
  value.

## 4. `traffic_light`

### Findings

- The top-level natural-language spec clearly says:
  - green for 60 cycles
  - yellow for 5 cycles
  - red for 10 cycles
  - when the pedestrian button is pressed, if the remaining green time is
    larger than 10, it is shortened to 10
- But the later "Implementation" sketch says:
  - `s1_red` transitions when `cnt == 3`
  - `s2_yellow` transitions when `cnt == 3`
  - `s3_green` transitions when `cnt == 3`
- At the same time, the counter is reloaded with `10/60/5` in different states.
- The current testbench mostly checks those reload values and a few sampled
  points, rather than strictly validating the actual 60/5/10 durations.

### Diagnosis

- The main error here is in the `spec` itself.
- The first half reads like "the intended task behavior", while the latter half
  reads like "one particular implementation sketch", and they are not
  consistent.
- The current `tb` clearly follows the later implementation sketch more than the
  opening natural-language requirements.

### If We Only Fix the Testbench

- There are two defensible directions:
  - if we emphasize the top-level natural-language spec, we should test
    `60/5/10`
  - if we emphasize the latter implementation sketch, we should test
    `cnt==3` transitions
- Given your stated goal of not "repairing the task with outside priors", but
  instead observing where the task text itself guides the model, the second
  direction is more informative:
  - keep the semantics that `pass_request` shortens the remaining green time to
    `10`
  - rewrite the transition checks around the `clock==3` sketch semantics

### Current Targeted Revision

- Rewrote the state checks around the latter implementation sketch: wait until a
  given state reaches `clock==3`, then check whether it promptly transitions to
  the next light state.
- Stopped using fixed `60/5/10` durations as the direct pass/fail criterion.
- Kept the `pass_request` test and checked whether the green countdown is
  shortened to `10` or less.

## 5. `width_8to16`

### Findings

- The spec says:
  - the first 8-bit data item goes into the upper 8 bits
  - after two inputs, `valid_out` and `data_out` are produced on the "next
    cycle"
- The reference RTL actually behaves as follows:
  - the first valid input is latched
  - when the second valid input arrives, the same rising edge updates
    `valid_out <= 1` and `data_out <= {data_lock, data_in}`
- The original testbench can pass the reference RTL, but it has two problems:
  - it changes `valid_in/data_in` on clock edges and therefore introduces a race
  - it does not really separate "output on the next cycle after the second
    input" from "output register updated on the same sampled edge as the second
    input"

### Diagnosis

- This is a task where both the `spec` and the `tb` are not clean.
- The phrase "next clock cycle after the two data inputs" can be read as
  requiring a strict extra-cycle delay.
- The current reference RTL / testbench instead behaves more like: "the
  concatenation is completed when the second valid input arrives, and becomes
  stably observable after that sampled edge."

### If We Only Fix the Testbench

- First, we should remove the race: all inputs should change on `negedge` or
  outside the sampling window.
- Second, we must choose one semantic interpretation:
  - if we follow the literal spec, then we should wait one extra cycle after the
    second `valid_in` before checking `valid_out/data_out`
  - if we follow the reference-RTL interpretation, then the result can be
    treated as valid immediately after the sampled edge carrying the second
    input

### Current Targeted Revision

- Moved all input driving to `negedge clk` to remove the race.
- Explicitly checked `valid_out/data_out` as an output that appears on the next
  cycle after the second byte.
- Added three concatenation scenarios: consecutive bytes, spaced bytes, and a
  second consecutive input sequence.

## 6. `asyn_fifo`

### Findings

- The spec begins by setting `DEPTH = 16`.
- Immediately after that, it also says:
  - "Use 4-bit Gray code as a read/write pointer for a FIFO with depth 8"
  - "using the lower three digits ... as the address"
- That directly conflicts with `DEPTH = 16`.
- The reference RTL uses:
  - `ADDR_WIDTH = $clog2(DEPTH)`
  - when `DEPTH=16`, the address width is 4, and the pointer including the wrap
    bit is even wider
- The testbench functionally aligns with the reference RTL, but it contains
  `break;`, which Icarus cannot compile.

### Diagnosis

- The main problem here is the `spec` itself being self-contradictory.
- The main `tb` issue is simulator compatibility rather than pure functional
  meaning:
  - under the current `iverilog`-oriented pipeline setup, the testbench does not
    even compile by itself

### If We Only Fix the Testbench

- We should not hard-code "full exactly at depth 16" into the testbench,
  because the spec simultaneously talks about depth 8 and lower-three-bit
  addressing.
- A safer testbench should prioritize:
  - FIFO ordering
  - `rempty` asserted when empty
  - `wfull` eventually asserted after sustained writes
  - `wfull` cleared after draining data
- The testbench should also remove `break` and use Icarus-compatible constructs.

### Current Targeted Revision

- Removed the dependency on `wfull.txt / rempty.txt / tdata.txt` trace files.
- Removed `break` and other Icarus-incompatible constructs.
- Stopped hard-coding capacity as 8 or 16, and instead checked FIFO ordering,
  `rempty`, and the eventual appearance of `wfull` under sustained writes.

## 7. `fixed_point_substractor`

### Findings

- The task name `fixed_point_substractor` strongly nudges the model toward
  "standard arithmetic subtraction".
- But if the branch logic in the prompt is translated literally, it yields a
  different, non-standard but internally self-consistent behavior.
- The original benchmark testbench is mostly evaluating `expected_result`
  according to that branch logic.
- However, it also contains an implementation bug:
  `a = $random % (1 << N)` causes input contamination with `x` under
  `iverilog` when `N=32`.
- So the real issue is not simply that "the testbench privately changed the
  task", but rather:
  - the task name, high-level meaning, and branch-level rules are pulling in
    different directions
  - the benchmark testbench is further polluted by `x` propagation effects

### Diagnosis

- This is one of the clearest examples among the seven tasks where different
  signals inside the `spec` conflict with each other.
- The original benchmark `tb` is not just "plainly wrong" semantically; it is
  actually executing one finer-grained layer of the prompt text.
- But its implementation bug makes the original pass/fail results less
  trustworthy than they appear.
- Meanwhile, an LLM is very likely to be pulled toward the task name
  `substractor` and toward standard arithmetic priors, and therefore to perform
  an implicit semantic repair.

### If We Only Fix the Testbench

- This task really needs to be split into two experiments:
  - **literal experiment**: keep testing according to the branch rules in the
    prompt, which is closer to the literal spec
  - **semantic-repair experiment**: test according to true signed fixed-point
    subtraction, which is closer to the task name plus high-level meaning
- The fact that your method's candidates drift toward two's complement or
  standard subtraction is not arbitrary; the model is actively choosing the
  second interpretation.

### Current Targeted Revision

- The main `testbench.v` keeps the original benchmark's spec-literal branch
  structure.
- It only fixes the random-input-generation bug by using fully-defined 32-bit
  random inputs, avoiding `x` contamination.
- Two additional comparison testbenches are kept:
  - `testbench_true_subtraction_signmag.v`: true sign-magnitude subtraction
  - `testbench_twos_complement.v`: true two's-complement subtraction

## Conclusion

If your next experiment is:

> do not change the spec, only repair the testbench so that it tests what the
> spec originally intended

then these seven tasks can be roughly grouped into three categories:

### A. Tasks where the testbench should clearly be fixed first

- `multi_pipe_8bit`
- `alu`
- `width_8to16`

Reason:

- the original testbench privately injected timing, latency, or coverage
  assumptions that the spec never stated, or it severely under-tested key
  semantics

### B. Tasks where the spec itself is already distorted, and the testbench is
mostly following that distortion

- `fixed_point_substractor`
- `traffic_light`
- `asyn_fifo`

Reason:

- without first deciding what the spec really means, there is no clean way to
  "just fix the testbench"

### C. Tasks where the spec is ambiguous and the testbench chose an overly
specific interpretation

- `parallel2serial`

Reason:

- we first need to decide the interface contract, and only then talk about the
  correct testbench

## Direct Suggestions for Your Experimental Design

If you want to measure:

> how much would my method's accuracy improve if, without changing the spec
> text, I only repaired the testbench so that it matches the intended meaning?

then I recommend splitting the seven tasks into two rounds:

1. **Start with the "testbench can be directly repaired" group**
   - `multi_pipe_8bit`
   - `alu`
   - `width_8to16`

2. **Then handle the "spec intention must be manually judged first" group**
   - `fixed_point_substractor`
   - `traffic_light`
   - `asyn_fifo`
   - `parallel2serial`

The reason is that for the second group, the "correct" version of the testbench
itself already depends on your interpretation of the intended meaning of the
spec, so the task is no longer a purely mechanical testbench repair.
