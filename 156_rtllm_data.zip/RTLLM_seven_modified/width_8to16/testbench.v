`timescale 1ns/1ns

module testbench;
    reg rst_n;
    reg valid_in;
    reg clk;
    reg [7:0] data_in;
    wire valid_out;
    wire [15:0] data_out;

    integer errors;

    width_8to16 dut (
        .clk(clk),
        .rst_n(rst_n),
        .valid_in(valid_in),
        .data_in(data_in),
        .valid_out(valid_out),
        .data_out(data_out)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    task drive_input;
        input vin;
        input [7:0] din;
        begin
            @(negedge clk);
            valid_in = vin;
            data_in = din;
        end
    endtask

    task sample_output;
        input exp_valid;
        input [15:0] exp_data;
        input check_data;
        input [127:0] label;
        begin
            @(posedge clk);
            #1;
            if (valid_out !== exp_valid) begin
                errors = errors + 1;
                $display("%0s: valid_out mismatch, got %b expected %b", label, valid_out, exp_valid);
            end
            if (check_data && data_out !== exp_data) begin
                errors = errors + 1;
                $display("%0s: data_out mismatch, got %h expected %h", label, data_out, exp_data);
            end
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 1'b0;
        valid_in = 1'b0;
        data_in = 8'h00;

        sample_output(1'b0, 16'h0000, 1'b0, "reset");

        @(negedge clk);
        rst_n = 1'b1;

        // Two back-to-back valid bytes should form one 16-bit word,
        // with the output appearing in the next cycle after the second byte.
        drive_input(1'b1, 8'hA0);
        sample_output(1'b0, 16'h0000, 1'b0, "first_byte_of_pair1");
        drive_input(1'b1, 8'hA1);
        sample_output(1'b0, 16'h0000, 1'b0, "second_byte_capture_pair1");
        drive_input(1'b0, 8'h00);
        sample_output(1'b1, 16'hA0A1, 1'b1, "output_pair1");
        drive_input(1'b0, 8'h00);
        sample_output(1'b0, 16'hA0A1, 1'b0, "idle_after_pair1");

        // A gap between the two valid bytes should not discard the first byte.
        drive_input(1'b1, 8'hB0);
        sample_output(1'b0, 16'hA0A1, 1'b0, "first_byte_of_pair2");
        drive_input(1'b0, 8'h00);
        sample_output(1'b0, 16'hA0A1, 1'b0, "gap_between_pair2_bytes");
        drive_input(1'b1, 8'hB1);
        sample_output(1'b0, 16'hA0A1, 1'b0, "second_byte_capture_pair2");
        drive_input(1'b0, 8'h00);
        sample_output(1'b1, 16'hB0B1, 1'b1, "output_pair2");
        drive_input(1'b0, 8'h00);
        sample_output(1'b0, 16'hB0B1, 1'b0, "idle_after_pair2");

        // Another back-to-back pair.
        drive_input(1'b1, 8'h12);
        sample_output(1'b0, 16'hB0B1, 1'b0, "first_byte_of_pair3");
        drive_input(1'b1, 8'h34);
        sample_output(1'b0, 16'hB0B1, 1'b0, "second_byte_capture_pair3");
        drive_input(1'b0, 8'h00);
        sample_output(1'b1, 16'h1234, 1'b1, "output_pair3");

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
