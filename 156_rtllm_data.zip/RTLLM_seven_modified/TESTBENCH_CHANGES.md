# Detailed Notes on the Seven Testbench Revisions

This document explains the revision strategy for the seven `testbench.v` files
inside `RTLLM_seven_modified/`.

There is one high-level principle:

- **do not freeze the internal habits, fixed latency, or historical bugs of one
  reference RTL implementation into the task definition**
- **try to test only the externally observable behavior that the spec is
  actually trying to express**

Additional notes:

- I ran a quick smoke test on the revised testbenches.
- The new `alu` testbench can pass the direct-baseline candidate you mentioned
  earlier:
  - `spec_direct_baseline/alu2/artifacts/generated/candidate.v` from a local
    rerun artifact
- The reference RTL for
  `multi_pipe_8bit / parallel2serial / traffic_light / width_8to16 / asyn_fifo`
  can pass the new testbenches.
- For `fixed_point_substractor`, I currently keep three testbenches:
  - `testbench.v`: the **spec-literal** version after fixing the benchmark
    implementation bug
  - `testbench_true_subtraction_signmag.v`: a sign-magnitude "true subtraction"
    comparison experiment
  - `testbench_twos_complement.v`: a two's-complement "true subtraction"
    comparison experiment

## 1. `alu`

Modified file:

- `RTLLM_seven_modified/alu/testbench.v`

Problems in the original testbench:

- It only checks `r`
- It barely checks `zero/carry/negative/overflow/flag`
- It uses only one fixed input pair
- The `LUI` result depends entirely on `reference.dat`
- It reads `reference[0:31]`, but the file actually has only 17 entries

What changed:

- Removed the single-point lookup-table style driven by `reference.dat`
- Replaced it with multiple representative operation cases:
  - `ADD`
  - `ADDU`
  - `SUB`
  - `AND/OR/XOR`
  - `SLT/SLTU`
  - `SLL/SRA`
  - `LUI`
- Explicitly checks:
  - `r`
  - `zero`
  - `negative`
  - `overflow`
  - `carry` in the appropriate cases
  - whether `flag` is literally `1` for `SLT/SLTU` as written in the spec
  - whether `flag` is high-impedance `z` for non-`SLT/SLTU` cases

Why this change:

- The core issue is that the original testbench simply did not test more than
  half of the output semantics described by the spec
- This task must be interpreted strictly according to the literal spec wording,
  not through outside priors
- Because the spec simultaneously says that `flag` is the result of
  `slt/sltu` and also that `flag=1` for `SLT/SLTU`, the new testbench follows
  the literal wording of the latter sentence
- Accordingly, the new testbench checks `LUI` using the literal
  `upper 16 bits of a` requirement, rather than rewriting it based on common ISA
  conventions
- After this revision, implementations that truly "read what the spec says"
  are rewarded, instead of implementations that merely happen to match
  `reference.dat`

Additional notes:

- The current reference RTL is rejected by the new testbench because it does not
  drive `carry/negative/overflow` correctly
- Once `flag` and `LUI` are tightened to the literal spec wording, your earlier
  `alu` direct-baseline candidate also stops passing
- This is exactly the point: as long as the testbench leaves some
  "implementation habit interpretation space", certain candidates may look
  correct; once we return strictly to the spec, the conclusion changes

## 2. `multi_pipe_8bit`

Modified file:

- `RTLLM_seven_modified/multi_pipe_8bit/testbench.v`

Problems in the original testbench:

- It assumes one very specific pipeline latency
- It even contains logic that says "if the correct result appears too early,
  count that as an error"
- That is not something the spec explicitly requires

What changed:

- Changed the flow to "issue one multiplication request, then wait for
  `mul_en_out`"
- If `mul_en_out` goes high and `mul_out == mul_a * mul_b`, the case passes
- When `mul_en_out == 0`, the testbench requires `mul_out == 0`
- Uses multiple input cases instead of one fixed script

Why this change:

- The spec is trying to express "a pipelined multiplier with a validity signal"
- The spec does not require one fixed latency
- Therefore the new testbench no longer punishes implementations that are
  faster but still correct

## 3. `parallel2serial`

Modified file:

- `RTLLM_seven_modified/parallel2serial/testbench.v`

Problems in the original testbench:

- It effectively forces the module to behave like "one frame is reloaded every
  four cycles"
- It also assumes that `valid_out` is `1` only for the first bit
- That interpretation may be defensible, but the original testbench encoded it
  in a brittle way

What changed:

- Kept a conservative interpretation that is still close to the current spec:
  - when `valid_out=1`, output the MSB of one frame
  - output the remaining three bits over the next three cycles
- Changed the checking style from "hard-code specific cycle indices" to
  "wait for frame start"
- Added a second `d` input and checked that the next frame loads the new 4-bit
  value

Why this change:

- The spec itself is somewhat ambiguous
- So instead of inventing a new protocol, I changed the testbench from
  "hard-coded cycle points" to "check around frame boundaries"
- That makes it more like a test of the externally observable
  parallel-to-serial behavior

## 4. `traffic_light`

Modified file:

- `RTLLM_seven_modified/traffic_light/testbench.v`

Problems in the original testbench:

- The spec is internally inconsistent:
  - the first half says `60/5/10`
  - the later implementation sketch repeatedly transitions at `cnt==3`
- If the testbench focuses only on the first-half natural language, then many
  candidates that clearly follow the later implementation sketch will all be
  rejected

What changed:

- Rewrote the test around the literal later-half implementation sketch:
  - wait until a given state reaches `clock==3`
  - check that it soon transitions to the next light state
- Kept the `pass_request` check:
  - issue the request while the light is green and `clock > 10`
  - check that the green countdown is shortened to `10` or less
  - then still check the transition into yellow according to the sketch

Why this change:

- You explicitly said that this should follow the spec, and the latter
  implementation sketch is also part of the prompt
- Since many candidates are clearly implementing that sketch, this testbench
  should first verify whether they faithfully implement the second-half sketch
- After retesting with this version, your method reaches `20/20` on
  `traffic_light`, which suggests the model is not behaving randomly; it is
  consistently latching onto that sketch

## 5. `width_8to16`

Modified file:

- `RTLLM_seven_modified/width_8to16/testbench.v`

Problems in the original testbench:

- Input changes are scheduled on the sampling clock edge, which creates a race
- The check for "when exactly the second byte forms the output" is not clean
- Coverage of separated-byte concatenation cases is weak

What changed:

- Moved all input updates to `negedge clk` to avoid races
- Explicitly tests three scenarios:
  - two consecutive valid bytes forming one 16-bit output
  - two valid bytes separated by one invalid cycle, which should still form one
    pair
  - another consecutive-input case to confirm stability

Why this change:

- The intended semantics are "two valid 8-bit inputs are concatenated into one
  16-bit output"
- The new testbench validates that contract directly instead of depending on
  lucky sampling under edge races

## 6. `asyn_fifo`

Modified file:

- `RTLLM_seven_modified/asyn_fifo/testbench.v`

Problems in the original testbench:

- It compares against external reference traces in
  `wfull.txt / rempty.txt / tdata.txt`
- It contains `break`, which fails immediately under `iverilog`
- It depends too heavily on historical waveform files instead of validating the
  specification

What changed:

- Removed the dependency on external text traces
- First runs a small write/read cycle that checks only the most basic FIFO
  ordering and empty-flag behavior
- Then runs a sustained-write test until `wfull` appears
- No longer hard-codes "exactly 16 writes means full"
- Uses Icarus-compatible code throughout and removes `break`

Why this change:

- Your current goal is to make the testbench test what the spec was meant to
  express
- But the spec itself simultaneously says `DEPTH=16` and "depth 8 / lower three
  bits address"
- So the new testbench focuses only on unambiguous external behavior:
  - FIFO ordering
  - correct full/empty flag behavior
  - correct ordering across the clock-domain boundary
- It no longer forces one specific capacity interpretation back into the task

## 7. `fixed_point_substractor`

Modified files:

- `RTLLM_seven_modified/fixed_point_substractor/testbench.v`
- `RTLLM_seven_modified/fixed_point_substractor/testbench_true_subtraction_signmag.v`
- `RTLLM_seven_modified/fixed_point_substractor/testbench_twos_complement.v`

Problems in the original testbench:

- The benchmark testbench has two layers of problems:
  - semantically, it is checking the prompt's branch rules in a
    spec-literal way
  - implementation-wise, it generates inputs with
    `a = $random % (1 << N)`; when `N=32`, `1 << N` becomes `0` under
    `iverilog`, which contaminates inputs with `x`
- As a result, some candidates may appear to pass or fail only because their
  `x` propagation behavior differs

What changed:

- Main version `testbench.v`:
  - keeps the original benchmark's branch logic, i.e. the **spec-literal**
    semantics
  - fixes only the input-generation bug so that the test uses fully-defined
    32-bit random inputs
  - no longer uses the `(1 << N)` pattern that produces `x`

I also added another version:

- `testbench_true_subtraction_signmag.v`
- This version interprets inputs and outputs in **sign-magnitude** form
- It directly checks the "true subtraction" semantics
- It is meant to answer: if we interpret the task as a sign-magnitude
  subtractor, what do the model outputs actually do?

And I added one more version:

- `testbench_twos_complement.v`
- This version interprets both inputs and outputs as **two's-complement signed
  fixed-point**
- It directly checks `$signed(c) == $signed(a) - $signed(b)`
- It is meant to answer: if we test according to the "two's complement form"
  that the method's candidates themselves often write down, are they actually
  performing standard two's-complement subtraction correctly?

Why this change:

- The role of the main `testbench.v` is now very clear:
  - it is the spec-literal testbench after fixing the implementation bug
  - it is not a semantic-repair version
- The two additional testbenches also have very clear roles:
  - `testbench_true_subtraction_signmag.v`: true sign-magnitude subtraction
    comparison
  - `testbench_twos_complement.v`: true two's-complement subtraction
    comparison
- More concretely:
  - `testbench.v` tests the branch rules of the bug-fixed spec-literal version
  - `testbench_true_subtraction_signmag.v` tests "true subtraction under
    sign-magnitude"
  - `testbench_twos_complement.v` tests "true subtraction under
    two's-complement"
- Looking at both versions together is what lets us distinguish whether the
  model is really repairing the semantics, or merely wrapping the old behavior
  in a partial two's-complement shell

## Conclusion

The overall direction of this batch of testbench changes is:

- `alu`: move from "compare `r` against a lookup table" to "test the external
  ALU semantics"
- `multi_pipe_8bit`: remove the fixed-latency bias
- `parallel2serial`: test frame semantics instead of hard-coded time points
- `traffic_light`: follow the latter-half `cnt==3` implementation sketch in the
  spec while preserving the button-shortening semantics
- `width_8to16`: test the two-byte concatenation contract and eliminate races
- `asyn_fifo`: test FIFO behavior directly instead of depending on legacy trace
  files
- `fixed_point_substractor`: revert the main version to a bug-fixed
  spec-literal test, while keeping two "true subtraction" comparison
  experiments

If you want, the next step can be either of the following:

1. run these seven new testbenches on the model outputs you care about and
   roughly estimate how much the accuracy may change when only the testbench is
   fixed
2. add a more paper-style summary that groups the seven tasks into
   "testbench-bias", "spec-contaminated", and "spec-ambiguous" categories
