# Summary of Testbench Revisions for Seven Tasks

This document is a short paper-oriented summary of the main testbench changes
for the seven selected RTLLM2.0 tasks, together with the motivation for each
change.

Overall principles:

- Add checks for key functional behaviors that the original testbench missed
- Remove implementation assumptions that were never explicitly required by the spec
- Prefer validating externally observable behavior over relying on the internal habits of a particular reference RTL

## `alu`

Changes:

- Removed the single-point lookup-style test driven by `reference.dat`
- Expanded checking from only `r` to `r / zero / carry / negative / overflow / flag`
- Added multiple representative operation cases: `ADD / ADDU / SUB / AND / OR / XOR / SLT / SLTU / SLL / SRA / LUI`
- Checked `flag` for `SLT/SLTU` and the `LUI` result directly against the literal spec wording

Why:

- The original testbench severely under-tested the ALU flag semantics
- It relied too heavily on the reference file and therefore did not faithfully reflect the output behavior defined by the spec

## `multi_pipe_8bit`

Changes:

- Removed the implicit requirement of a fixed pipeline latency
- Changed the check to verify `mul_out == mul_a * mul_b` when `mul_en_out` goes high
- Added a check that the output should be invalid or zero when `mul_en_out == 0`
- Used multiple input cases instead of a single fixed flow

Why:

- The original testbench treated one specific latency as part of the task requirement and even penalized implementations that produced the correct result earlier
- The spec is really describing pipelined multiplication with a validity signal, not a fixed cycle count

## `parallel2serial`

Changes:

- Kept the frame-level interpretation that is closest to the current spec:
  - output the first bit of a frame when `valid_out=1`
  - output the remaining three bits on subsequent cycles
- Changed the check from hard-coded cycle points to frame-start-based bit-by-bit validation
- Added a second input pattern to check whether the next frame correctly loads a new `d`

Why:

- The original testbench used an overly rigid interpretation of the serialization timing
- The revised version still tests the same external protocol, but no longer depends on fixed cycle checkpoints

## `traffic_light`

Changes:

- Rewrote the state checks around the `cnt==3` transition logic in the second-half implementation sketch of the spec
- Stopped directly judging state transitions by fixed `60/5/10` durations
- Kept the `pass_request` test:
  - issue a request when the light is green and the remaining time is greater than `10`
  - check whether the remaining countdown is shortened to `10` or less

Why:

- The spec is internally inconsistent: the first half says `60/5/10`, while the later implementation sketch transitions at `cnt==3`
- To avoid injecting outside priors, the revised testbench faithfully validates the state-machine sketch explicitly given in the latter half of the prompt

## `width_8to16`

Changes:

- Moved all input updates to `negedge clk` to remove race conditions
- Explicitly checked two-byte concatenation behavior instead of relying on accidental edge-order sampling
- Added three scenarios:
  - two consecutive valid bytes
  - two valid bytes separated by an invalid cycle
  - another consecutive-input case to confirm stability

Why:

- The original testbench had a timing race problem
- It did not cleanly cover the core semantics of combining two 8-bit inputs into one 16-bit output

## `asyn_fifo`

Changes:

- Removed the dependency on the `wfull.txt / rempty.txt / tdata.txt` trace files
- Removed `break` and other Icarus-incompatible constructs
- Switched to directly checking basic FIFO external behavior:
  - write/read ordering
  - `rempty` asserted when empty
  - `wfull` eventually asserted after sustained writes

Why:

- The original testbench depended on historical reference traces, which is not ideal for spec-based validation
- It also had simulator compatibility issues
- Because the task spec is internally inconsistent about FIFO depth, it is more appropriate to validate only unambiguous external FIFO behavior

## `fixed_point_substractor`

Changes:

- Main version `testbench.v`:
  - kept the original benchmark's spec-literal branch logic
  - fixed the random-input generation bug so that `(1 << N)` at `N=32` does not collapse to `0` under `iverilog` and contaminate inputs with `x`
- Also retained two comparison variants:
  - `testbench_true_subtraction_signmag.v`
  - `testbench_twos_complement.v`

Why:

- Although the original benchmark testbench was closer to the literal spec, it had an input-generation bug that polluted some pass/fail outcomes through `x` propagation
- The goal of the main revision was therefore not to rewrite the semantics, but only to fix the implementation bug in the testbench
- The two additional "true subtraction" variants were kept to study whether the model actively departs from the spec and repairs the behavior into standard arithmetic

## Paper-Ready High-Level Summary

- `alu`: Added checks for the missing flag and multi-operation semantics and removed the dependency on the reference table.
- `multi_pipe_8bit`: Removed the implicit fixed-latency constraint and instead validated multiplication correctness when the output is marked valid.
- `parallel2serial`: Kept the original frame-level protocol interpretation, but removed the brittle dependence on fixed cycle checkpoints.
- `traffic_light`: Resolved the spec conflict by validating against the `cnt==3` state-transition semantics in the latter implementation sketch.
- `width_8to16`: Eliminated the input-driving race and expanded coverage of byte-concatenation scenarios.
- `asyn_fifo`: Removed external trace dependencies and simulator-incompatible constructs, replacing them with direct checks of basic FIFO behavior.
- `fixed_point_substractor`: Kept the main version spec-literal and only fixed the benchmark's input-generation bug, while retaining two comparison variants for true subtraction semantics.
