`timescale 1ns/1ns

module parallel2serial_tb;
    reg clk;
    reg rst_n;
    reg [3:0] d;
    wire valid_out;
    wire dout;

    integer errors;
    integer timeout;

    parallel2serial dut (
        .clk(clk),
        .rst_n(rst_n),
        .d(d),
        .valid_out(valid_out),
        .dout(dout)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    task wait_for_frame_start;
        begin
            timeout = 0;
            while (valid_out !== 1'b1 && timeout < 20) begin
                @(posedge clk);
                #1;
                timeout = timeout + 1;
            end
            if (valid_out !== 1'b1) begin
                errors = errors + 1;
                $display("parallel2serial never produced a frame start");
            end
        end
    endtask

    task check_frame;
        input [3:0] frame_data;
        begin
            wait_for_frame_start;
            if (dout !== frame_data[3] || valid_out !== 1'b1) begin
                errors = errors + 1;
                $display("Frame start mismatch: got dout=%b valid_out=%b expected dout=%b valid_out=1", dout, valid_out, frame_data[3]);
            end

            @(posedge clk); #1;
            if (dout !== frame_data[2] || valid_out !== 1'b0) begin
                errors = errors + 1;
                $display("Second serial bit mismatch: got dout=%b valid_out=%b expected dout=%b valid_out=0", dout, valid_out, frame_data[2]);
            end

            @(posedge clk); #1;
            if (dout !== frame_data[1] || valid_out !== 1'b0) begin
                errors = errors + 1;
                $display("Third serial bit mismatch: got dout=%b valid_out=%b expected dout=%b valid_out=0", dout, valid_out, frame_data[1]);
            end

            @(posedge clk); #1;
            if (dout !== frame_data[0] || valid_out !== 1'b0) begin
                errors = errors + 1;
                $display("Fourth serial bit mismatch: got dout=%b valid_out=%b expected dout=%b valid_out=0", dout, valid_out, frame_data[0]);
            end
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 1'b0;
        d = 4'b1010;

        @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

        check_frame(4'b1010);

        // Update d for the next frame and verify the new parallel word is reloaded.
        @(negedge clk);
        d = 4'b0110;
        check_frame(4'b0110);

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end
        $finish;
    end

endmodule
