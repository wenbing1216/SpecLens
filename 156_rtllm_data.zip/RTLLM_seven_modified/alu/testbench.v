`timescale 1ns / 1ps

module test_alu;

    reg [31:0] a;
    reg [31:0] b;
    reg [5:0] aluc;
    wire [31:0] r;
    wire zero;
    wire carry;
    wire negative;
    wire overflow;
    wire flag;

    integer errors;

    alu uut (
        .a(a),
        .b(b),
        .aluc(aluc),
        .r(r),
        .zero(zero),
        .carry(carry),
        .negative(negative),
        .overflow(overflow),
        .flag(flag)
    );

    parameter ADD  = 6'b100000;
    parameter ADDU = 6'b100001;
    parameter SUB  = 6'b100010;
    parameter AND_ = 6'b100100;
    parameter OR_  = 6'b100101;
    parameter XOR_ = 6'b100110;
    parameter SLT  = 6'b101010;
    parameter SLTU = 6'b101011;
    parameter SLL  = 6'b000000;
    parameter SRA  = 6'b000011;
    parameter LUI  = 6'b001111;

    task check_alu;
        input [31:0] ta;
        input [31:0] tb;
        input [5:0] top;
        input [31:0] exp_r;
        input exp_zero;
        input exp_negative;
        input exp_overflow;
        input check_carry;
        input exp_carry;
        input check_flag_value;
        input exp_flag;
        input expect_flag_z;
        begin
            a = ta;
            b = tb;
            aluc = top;
            #1;

            if (r !== exp_r) begin
                errors = errors + 1;
                $display("ALU result mismatch: op=%b a=%h b=%h r=%h expected=%h", top, ta, tb, r, exp_r);
            end
            if (zero !== exp_zero) begin
                errors = errors + 1;
                $display("ALU zero mismatch: op=%b a=%h b=%h zero=%b expected=%b", top, ta, tb, zero, exp_zero);
            end
            if (negative !== exp_negative) begin
                errors = errors + 1;
                $display("ALU negative mismatch: op=%b a=%h b=%h negative=%b expected=%b", top, ta, tb, negative, exp_negative);
            end
            if (overflow !== exp_overflow) begin
                errors = errors + 1;
                $display("ALU overflow mismatch: op=%b a=%h b=%h overflow=%b expected=%b", top, ta, tb, overflow, exp_overflow);
            end
            if (check_carry && carry !== exp_carry) begin
                errors = errors + 1;
                $display("ALU carry mismatch: op=%b a=%h b=%h carry=%b expected=%b", top, ta, tb, carry, exp_carry);
            end
            if (check_flag_value && flag !== exp_flag) begin
                errors = errors + 1;
                $display("ALU flag mismatch: op=%b a=%h b=%h flag=%b expected=%b", top, ta, tb, flag, exp_flag);
            end
            if (expect_flag_z && flag !== 1'bz) begin
                errors = errors + 1;
                $display("ALU flag should be high-impedance: op=%b a=%h b=%h flag=%b", top, ta, tb, flag);
            end
        end
    endtask

    initial begin
        errors = 0;
        a = 0;
        b = 0;
        aluc = 0;

        // ADD
        check_alu(32'h0000_0001, 32'h0000_0002, ADD, 32'h0000_0003, 1'b0, 1'b0, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b1);
        check_alu(32'h7fff_ffff, 32'h0000_0001, ADD, 32'h8000_0000, 1'b0, 1'b1, 1'b1, 1'b1, 1'b0, 1'b0, 1'b0, 1'b1);

        // ADDU
        check_alu(32'hffff_ffff, 32'h0000_0001, ADDU, 32'h0000_0000, 1'b1, 1'b0, 1'b0, 1'b1, 1'b1, 1'b0, 1'b0, 1'b1);

        // SUB: test externally observable arithmetic, zero, negative, overflow
        check_alu(32'h0000_0005, 32'h0000_0005, SUB, 32'h0000_0000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);
        check_alu(32'h8000_0000, 32'h0000_0001, SUB, 32'h7fff_ffff, 1'b0, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);

        // Logical ops
        check_alu(32'hf0f0_0000, 32'h0ff0_1234, AND_, 32'h00f0_0000, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);
        check_alu(32'hf0f0_0000, 32'h0ff0_1234, OR_,  32'hfff0_1234, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);
        check_alu(32'hffff_0000, 32'h00ff_00ff, XOR_, 32'hff00_00ff, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);

        // Set-less-than: follow the spec literally.
        // The result r still reflects the comparison result, while flag is checked
        // according to the spec sentence that says SLT/SLTU set flag to 1.
        check_alu(32'hffff_ffff, 32'h0000_0001, SLT,  32'h0000_0001, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b1, 1'b0);
        check_alu(32'h0000_0002, 32'hffff_ffff, SLT,  32'h0000_0000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b1, 1'b0);
        check_alu(32'hffff_ffff, 32'h0000_0000, SLTU, 32'h0000_0000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b1, 1'b0);
        check_alu(32'h0000_0001, 32'hffff_ffff, SLTU, 32'h0000_0001, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b1, 1'b0);

        // Shifts
        check_alu(32'h0000_0004, 32'h0000_0001, SLL, 32'h0000_0010, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);
        check_alu(32'h0000_0004, 32'hffff_fff0, SRA, 32'hffff_ffff, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);

        // LUI: use the upper 16 bits of a exactly as stated in the spec
        check_alu(32'h1234_5678, 32'h0000_0000, LUI, 32'h1234_0000, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1);

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end
        $finish;
    end

endmodule
