`timescale 1ns/1ns

module tb_traffic_light;

    reg clk;
    reg rst_n;
    reg pass_request;
    wire [7:0] clock;
    wire red;
    wire yellow;
    wire green;

    integer errors;
    integer timeout;

    traffic_light dut (
        .clk(clk),
        .rst_n(rst_n),
        .pass_request(pass_request),
        .clock(clock),
        .red(red),
        .yellow(yellow),
        .green(green)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    task wait_for_state;
        input exp_red;
        input exp_yellow;
        input exp_green;
        input integer max_cycles;
        begin
            timeout = 0;
            while (!(red === exp_red && yellow === exp_yellow && green === exp_green) && timeout < max_cycles) begin
                @(posedge clk);
                #1;
                timeout = timeout + 1;
            end
            if (!(red === exp_red && yellow === exp_yellow && green === exp_green)) begin
                errors = errors + 1;
                $display("Timed out waiting for state red=%b yellow=%b green=%b", exp_red, exp_yellow, exp_green);
            end
        end
    endtask

    task wait_for_state_and_clock3;
        input exp_red;
        input exp_yellow;
        input exp_green;
        input integer max_cycles;
        begin
            timeout = 0;
            while (!((red === exp_red) && (yellow === exp_yellow) && (green === exp_green) && (clock === 8'd3)) && timeout < max_cycles) begin
                @(posedge clk);
                #1;
                timeout = timeout + 1;
            end
            if (!((red === exp_red) && (yellow === exp_yellow) && (green === exp_green) && (clock === 8'd3))) begin
                errors = errors + 1;
                $display("Timed out waiting for state red=%b yellow=%b green=%b with clock=3", exp_red, exp_yellow, exp_green);
            end
        end
    endtask

    task expect_transition_within;
        input exp_red;
        input exp_yellow;
        input exp_green;
        input integer max_cycles;
        input [127:0] label;
        begin
            timeout = 0;
            while (!(red === exp_red && yellow === exp_yellow && green === exp_green) && timeout < max_cycles) begin
                @(posedge clk);
                #1;
                timeout = timeout + 1;
            end
            if (!(red === exp_red && yellow === exp_yellow && green === exp_green)) begin
                errors = errors + 1;
                $display("%0s: expected transition to red=%b yellow=%b green=%b", label, exp_red, exp_yellow, exp_green);
            end
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 1'b0;
        pass_request = 1'b0;

        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

        // Follow the implementation sketch literally:
        // each phase transitions when cnt reaches 3.
        wait_for_state(1'b1, 1'b0, 1'b0, 20);
        wait_for_state_and_clock3(1'b1, 1'b0, 1'b0, 20);
        expect_transition_within(1'b0, 1'b0, 1'b1, 3, "red_to_green");

        wait_for_state_and_clock3(1'b0, 1'b0, 1'b1, 80);
        expect_transition_within(1'b0, 1'b1, 1'b0, 3, "green_to_yellow");

        wait_for_state_and_clock3(1'b0, 1'b1, 1'b0, 20);
        expect_transition_within(1'b1, 1'b0, 1'b0, 3, "yellow_to_red");

        // On the next green phase, request shortening while the remaining green counter is above 10.
        wait_for_state_and_clock3(1'b1, 1'b0, 1'b0, 20);
        expect_transition_within(1'b0, 1'b0, 1'b1, 3, "second_red_to_green");
        while (!(green === 1'b1 && clock > 8'd10)) begin
            @(posedge clk);
            #1;
        end
        @(negedge clk);
        pass_request = 1'b1;
        @(posedge clk);
        #1;
        pass_request = 1'b0;
        if (clock > 8'd10) begin
            errors = errors + 1;
            $display("Green countdown should be shortened to 10 or less after pass_request, got %0d", clock);
        end
        wait_for_state_and_clock3(1'b0, 1'b0, 1'b1, 20);
        expect_transition_within(1'b0, 1'b1, 1'b0, 3, "shortened_green_to_yellow");

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
