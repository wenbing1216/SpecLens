`timescale 1ns/1ns

module asyn_fifo_tb;

    parameter WIDTH = 8;
    parameter DEPTH = 16;

    reg wclk;
    reg rclk;
    reg wrstn;
    reg rrstn;
    reg winc;
    reg rinc;
    reg [WIDTH-1:0] wdata;
    wire wfull;
    wire rempty;
    wire [WIDTH-1:0] rdata;

    reg [WIDTH-1:0] expected [0:63];
    integer errors;
    integer i;
    integer fill_count;
    integer max_fill_attempts;

    asyn_fifo #(
        .WIDTH(WIDTH),
        .DEPTH(DEPTH)
    ) dut (
        .wclk(wclk),
        .rclk(rclk),
        .wrstn(wrstn),
        .rrstn(rrstn),
        .winc(winc),
        .rinc(rinc),
        .wdata(wdata),
        .wfull(wfull),
        .rempty(rempty),
        .rdata(rdata)
    );

    initial wclk = 1'b0;
    initial rclk = 1'b0;
    always #5  wclk = ~wclk;
    always #10 rclk = ~rclk;

    task write_word;
        input [WIDTH-1:0] value;
        begin
            @(negedge wclk);
            wdata = value;
            winc = 1'b1;
            @(posedge wclk);
            #1;
            @(negedge wclk);
            winc = 1'b0;
        end
    endtask

    task read_word_and_check;
        input [WIDTH-1:0] exp_value;
        begin
            @(negedge rclk);
            rinc = 1'b1;
            @(posedge rclk);
            #1;
            if (rdata !== exp_value) begin
                errors = errors + 1;
                $display("FIFO data mismatch: got %h expected %h", rdata, exp_value);
            end
            @(negedge rclk);
            rinc = 1'b0;
        end
    endtask

    initial begin
        errors = 0;
        wrstn = 1'b0;
        rrstn = 1'b0;
        winc = 1'b0;
        rinc = 1'b0;
        wdata = {WIDTH{1'b0}};

        repeat (3) @(posedge wclk);
        repeat (2) @(posedge rclk);
        wrstn = 1'b1;
        rrstn = 1'b1;

        repeat (3) @(posedge rclk);
        #1;
        if (rempty !== 1'b1) begin
            errors = errors + 1;
            $display("FIFO should be empty after reset");
        end

        // First verify basic FIFO ordering without assuming a specific capacity.
        expected[0] = 8'h11;
        expected[1] = 8'h22;
        expected[2] = 8'h33;
        for (i = 0; i < 3; i = i + 1) begin
            if (wfull === 1'b1) begin
                errors = errors + 1;
                $display("FIFO became full unexpectedly during basic write test at index %0d", i);
            end
            write_word(expected[i]);
        end

        repeat (4) @(posedge rclk);
        #1;
        if (rempty !== 1'b0) begin
            errors = errors + 1;
            $display("FIFO should not be empty after a few successful writes");
        end

        for (i = 0; i < 3; i = i + 1) begin
            read_word_and_check(expected[i]);
        end

        repeat (4) @(posedge rclk);
        #1;
        if (rempty !== 1'b1) begin
            errors = errors + 1;
            $display("FIFO did not return to empty after draining the basic test data");
        end

        repeat (4) @(posedge wclk);
        #1;
        if (wfull !== 1'b0) begin
            errors = errors + 1;
            $display("FIFO should not remain full after the queue is drained");
        end

        // The spec is inconsistent about whether the intended depth is 8 or 16,
        // so only require that the FIFO eventually reports full after enough writes.
        fill_count = 0;
        max_fill_attempts = 32;
        while (wfull !== 1'b1 && fill_count < max_fill_attempts) begin
            expected[fill_count] = (8'h80 + fill_count[7:0]);
            write_word(expected[fill_count]);
            fill_count = fill_count + 1;
            repeat (1) @(posedge wclk);
            #1;
        end

        if (wfull !== 1'b1) begin
            errors = errors + 1;
            $display("FIFO never asserted wfull after %0d write attempts", fill_count);
        end

        repeat (4) @(posedge rclk);
        #1;
        if (rempty !== 1'b0) begin
            errors = errors + 1;
            $display("FIFO should not be empty after the fill sequence");
        end

        for (i = 0; i < fill_count; i = i + 1) begin
            read_word_and_check(expected[i]);
        end

        repeat (4) @(posedge rclk);
        #1;
        if (rempty !== 1'b1) begin
            errors = errors + 1;
            $display("FIFO did not assert rempty after all queued data was read");
        end

        repeat (4) @(posedge wclk);
        #1;
        if (wfull !== 1'b0) begin
            errors = errors + 1;
            $display("FIFO should clear wfull after the read side drains the queue");
        end

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
