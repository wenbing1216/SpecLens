`timescale 1ns / 1ps

module tb_fixed_point_subtractor;

    parameter Q = 8;
    parameter N = 16;

    reg [N-1:0] a;
    reg [N-1:0] b;
    wire [N-1:0] c;

    integer errors;

    fixed_point_subtractor #(
        .Q(Q),
        .N(N)
    ) uut (
        .a(a),
        .b(b),
        .c(c)
    );

    function [N-1:0] pack_sign_mag;
        input sign_bit;
        input [N-2:0] magnitude;
        begin
            pack_sign_mag = {sign_bit, magnitude};
        end
    endfunction

    function integer signed signmag_to_int;
        input [N-1:0] value;
        integer magnitude;
        begin
            magnitude = value[N-2:0];
            if (value[N-1])
                signmag_to_int = -magnitude;
            else
                signmag_to_int = magnitude;
        end
    endfunction

    function [N-1:0] int_to_signmag;
        input integer signed value;
        integer magnitude;
        begin
            if (value < 0) begin
                magnitude = -value;
                int_to_signmag = {1'b1, magnitude[N-2:0]};
            end else begin
                magnitude = value;
                int_to_signmag = {1'b0, magnitude[N-2:0]};
            end
            if (magnitude == 0)
                int_to_signmag[N-1] = 1'b0;
        end
    endfunction

    task check_case;
        input [N-1:0] ta;
        input [N-1:0] tb;
        reg [N-1:0] expected_result;
        integer signed diff_value;
        begin
            a = ta;
            b = tb;
            #1;

            diff_value = signmag_to_int(ta) - signmag_to_int(tb);
            expected_result = int_to_signmag(diff_value);

            if (c !== expected_result) begin
                errors = errors + 1;
                $display("Fixed-point subtract mismatch: a=%h b=%h c=%h expected=%h", ta, tb, c, expected_result);
            end
        end
    endtask

    initial begin
        errors = 0;
        a = 0;
        b = 0;

        // +1.5 - +0.5 = +1.0
        check_case(pack_sign_mag(1'b0, 15'd384), pack_sign_mag(1'b0, 15'd128));
        // +0.5 - +1.5 = -1.0
        check_case(pack_sign_mag(1'b0, 15'd128), pack_sign_mag(1'b0, 15'd384));
        // +1.5 - (-0.5) = +2.0
        check_case(pack_sign_mag(1'b0, 15'd384), pack_sign_mag(1'b1, 15'd128));
        // -1.5 - (+0.5) = -2.0
        check_case(pack_sign_mag(1'b1, 15'd384), pack_sign_mag(1'b0, 15'd128));
        // -1.5 - (-0.5) = -1.0
        check_case(pack_sign_mag(1'b1, 15'd384), pack_sign_mag(1'b1, 15'd128));
        // -0.5 - (-1.5) = +1.0
        check_case(pack_sign_mag(1'b1, 15'd128), pack_sign_mag(1'b1, 15'd384));
        // +1.0 - +1.0 = 0 with positive zero sign
        check_case(pack_sign_mag(1'b0, 15'd256), pack_sign_mag(1'b0, 15'd256));
        // -1.0 - (-1.0) = 0 with positive zero sign
        check_case(pack_sign_mag(1'b1, 15'd256), pack_sign_mag(1'b1, 15'd256));

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
