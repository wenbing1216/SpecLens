`timescale 1ns / 1ps

module tb_fixed_point_subtractor;

    parameter Q = 15;
    parameter N = 32;

    reg [N-1:0] a;
    reg [N-1:0] b;
    wire [N-1:0] c;

    integer error;
    integer i;
    reg [N-1:0] expected_result;

    fixed_point_subtractor #(
        .Q(Q),
        .N(N)
    ) uut (
        .a(a),
        .b(b),
        .c(c)
    );

    // Generate a fully defined N-bit random word without the old `(1 << N)` bug.
    function [N-1:0] rand_word;
        integer idx;
        begin
            for (idx = 0; idx < N; idx = idx + 1)
                rand_word[idx] = $random;
        end
    endfunction

    initial begin
        error = 0;
        a = 0;
        b = 0;

        for (i = 0; i < 100; i = i + 1) begin
            a = rand_word();
            b = rand_word();
            #10;

            // Preserve the original benchmark's spec-literal decision structure.
            if (a[N-1] == b[N-1]) begin
                expected_result = a - b;
            end
            else if (a[N-1] == 1'b0 && b[N-1] == 1'b1) begin
                if (a[N-2:0] > b[N-2:0])
                    expected_result = a + b;
                else
                    expected_result = b - a;
            end
            else begin
                if (a[N-2:0] > b[N-2:0])
                    expected_result = a - b;
                else
                    expected_result = b - a;
            end

            if (c !== expected_result) begin
                error = error + 1;
                $display(
                    "Test failed: a = %b, b = %b, c = %b, expected_result = %b",
                    a, b, c, expected_result
                );
            end
        end

        if (error == 0) begin
            $display("=========== Your Design Passed ===========");
        end else begin
            $display("=========== Test completed with %0d /100 failures ===========", error);
        end

        $finish;
    end

endmodule
