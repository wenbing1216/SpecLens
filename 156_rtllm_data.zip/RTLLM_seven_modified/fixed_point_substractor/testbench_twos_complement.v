`timescale 1ns / 1ps

module tb_fixed_point_subtractor_twos_complement;

    parameter Q = 8;
    parameter N = 16;

    reg [N-1:0] a;
    reg [N-1:0] b;
    wire [N-1:0] c;

    integer errors;
    integer signed expected;

    fixed_point_subtractor #(
        .Q(Q),
        .N(N)
    ) uut (
        .a(a),
        .b(b),
        .c(c)
    );

    task check_case;
        input signed [N-1:0] ta;
        input signed [N-1:0] tb;
        begin
            a = ta[N-1:0];
            b = tb[N-1:0];
            #1;

            expected = ta - tb;
            if ($signed(c) !== expected[N-1:0]) begin
                errors = errors + 1;
                $display(
                    "Two's complement subtract mismatch: a=%0d (0x%h) b=%0d (0x%h) c=%0d (0x%h) expected=%0d (0x%h)",
                    ta, ta[N-1:0], tb, tb[N-1:0], $signed(c), c, expected, expected[N-1:0]
                );
            end
        end
    endtask

    initial begin
        errors = 0;
        a = '0;
        b = '0;

        check_case(16'sd0, 16'sd0);
        check_case(16'sd384, 16'sd128);
        check_case(16'sd128, 16'sd384);
        check_case(16'sd384, -16'sd128);
        check_case(-16'sd384, 16'sd128);
        check_case(-16'sd384, -16'sd128);
        check_case(-16'sd128, -16'sd384);
        check_case(16'sd256, 16'sd256);
        check_case(-16'sd256, -16'sd256);
        check_case(16'sd1024, -16'sd512);
        check_case(-16'sd1024, 16'sd512);
        check_case(16'sd1234, 16'sd567);
        check_case(-16'sd1234, -16'sd567);
        check_case(16'sd1, -16'sd1);
        check_case(-16'sd1, 16'sd1);

        if (errors == 0) begin
            $display("===========Your Design Passed===========");
        end else begin
            $display("===========Test completed with %0d failures===========", errors);
        end

        $finish;
    end

endmodule
